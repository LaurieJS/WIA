$(document).ready(function() {
    $("#unicorn").sprite({ fps: 3, no_of_frames: 3 }).isDraggable();
    $("#planets").pan({fps: 25, speed: 2, dir: 'left'});
    $("#background").pan({fps: 5, speed: 2, dir: 'left'});
});